import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase es in item que otorga una vida al jugador.
 * 
 * @author AIVN 
 * @version 4 jul 2018
 */
public class Telaraña extends Items
{
    /**
     * Act - do whatever the Telaraña wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
