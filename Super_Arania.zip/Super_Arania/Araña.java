import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase Araña es el jugador principal el cual se mueve y mata a los 
 * 
 * @author AIVN 
 * @version 4-07-2018
 */
public class Araña extends Actor
{
    private GreenfootImage araña1;
    private GreenfootImage arañaDer;
    private GreenfootImage arañaIzq;
    private GreenfootImage arañaIzq2;
    private GreenfootImage arañaUp;
    private GreenfootImage arañaUp2;
    private GreenfootImage arañaDown;
    private int posicion;
    private int vidas;
    private int puntos;
    World world = getWorld();
    World mundo;
    private int disparo;
    private int xbala,ybala;
    Bala a,b;
    private int actor;
   
    /**
     * Constructor de la Clase Araña
     */
    public Araña()
    {
       getImage().scale(60,60);
       disparo=0;
       araña1 = new GreenfootImage("a1.png");
       araña1.scale(60,60);
       arañaDer = new GreenfootImage("a7.png");
       arañaDer.scale(60,60);
       arañaIzq = new GreenfootImage("a4.png");
       arañaIzq.scale(60,60);
       arañaIzq2 = new GreenfootImage("a5.png");
       arañaIzq2.scale(60,60);
       arañaUp = new GreenfootImage("a10.png");
       arañaUp.scale(60,60);
       arañaUp2 = new GreenfootImage("a11.png");
       arañaUp2.scale(60,60);
       arañaDown=new GreenfootImage("a1.png");
       arañaDown.scale(60,60);
       
       posicion = 0;
       vidas = 3;
       puntos = 0;
       actor = 0;
    }
    
    /**
     * Método que indica los puntos que vas a cumulando
     * @return puntos puntos que se acumulan al destruir rocas.
     */
    public int puntos()
    {
        return puntos;
    }
    
    /**
     * Act - do whatever the Araña wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        mundo=getWorld();
        checkPressKey();
        switchImage();
        lookForCerdo();
        lookForConejo();
        lookForAve();
        lookForRocaMuere();
        lookforRocaMata();
        mundo.showText("vidas "+ vidas, 80,50);
        mundo.showText("puntos "+ puntos, 1000,50);
        verificaVidas();
        dispara();
        lookForMoneda();
        lookForTelaraña();
    }   
    
    /**
     * Método que realiza el cambio de imagenes
     */
    public void switchImage()
    {
        if ( posicion == 0) 
        {
            setImage(araña1);
        }
        if ( posicion == 1) 
        {
            setImage(arañaDer);
        }
        if (posicion == 2) 
        {
            setImage(arañaIzq);
        }
        if ( posicion == 3) 
        {
            setImage(arañaUp);
        }
        if ( posicion == 4) 
        {
            setImage(arañaDown);
        }
        
    }
    
    /**
     * Mŕtodo que realiza el cambio de moviemiento de la araña y dispar la bala
     */
    public void checkPressKey()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            //setRotation(180);
            posicion = 2;
            muevete();
            setRotation(0);
        }
        
        else
        {
            if(Greenfoot.isKeyDown("right"))
            {
             // setRotation(0);
              posicion = 1;
              muevete();
              setRotation(0);
            }
            else
            {
                if (Greenfoot.isKeyDown("up"))
                {
                    //setRotation(270);
                    posicion = 3;
                    muevete();
                    setRotation(0);
                }
                else
                {
                    if (Greenfoot.isKeyDown("down"))
                    {
                        //setRotation(90);
                        posicion = 4;
                        muevete();
                        setRotation(0);
                    }
                    else
                    {
                        if(Greenfoot.isKeyDown("x"))
                        {
                            if(actor == 1)
                            {
                                mundo.removeObject(a);
                            }
                            disparo = 1;
                            xbala = this.getX();
                            ybala = this.getY();
                            dispara();
                        }
                        else
                        {
                            posicion=0;
                            setRotation(0);
                        }
                    }
                }
            }
            
        }
    }
    
    /**
     * Método que reliza el movimiento de la araña
     */
    public void muevete()
    {
        setRotation(0);
        if ( posicion == 1) 
        {
            setRotation(0);
            move(13);
        }
            if ( posicion == 2) 
        {
            setRotation(180);
            move(13);
        }
            if ( posicion == 3) 
        {
            setRotation(270);
            move(13);
        }
            if ( posicion == 4) 
        {
            setRotation(90);
            move(13);
        }
      
    }
    
    /**
     * Método que espera un Cerdo si lo toca este desaparece del mundo y muere
     */
    public void lookForCerdo()
    {
        if ( isTouching(Cerdo.class) )
            {
                removeTouching(Cerdo.class);
                sumaVida();
                Greenfoot.playSound("chillido.wav");
            }
    }
    
    /**
     * Método que espera un Conejo si lo toca este desaparece del mundo y muere
     */
    public void lookForConejo()
    {
        if ( isTouching(Conejo.class) )
            {
                removeTouching(Conejo.class);
                sumaVida();
                Greenfoot.playSound("rabbit.wav");
            }
    }
    
    /**
     * Método que espera un Ave si lo toca este desaparece del mundo y muere
     */
    public void lookForAve()
    {
        if ( isTouching(Ave.class) )
            {
                removeTouching(Ave.class);
                sumaVida(); 
                Greenfoot.playSound("ave.wav");
            }
    }
    
    /**
     * Método que te quita vidas y te coloca en una posicion inicial cada vez que pierdes una.
     */
    public void quitaVida()
    {
        this.setLocation(100,100);
        vidas--;
    }
    
    /**
     * Método que espera una Roca para destruirla y le da vidas a la araña
     */
    public void lookForRocaMuere()
    {
        if ( isTouching(RocaMuere.class) )
            {
                removeTouching(RocaMuere.class);
                sumaVida();
                Greenfoot.playSound("roca.wav");
            }
    }
    
    /**
     * Método que te da la opcion de tomas la moneda y te envia al nivel 3
     */
    public void sumaVida2()
    {
        mundo3 loser = new mundo3();
        puntos = puntos + 100;
        vidas++;
        if(vidas > 0)
        {
            if(puntos > 100)
            {
              Greenfoot.setWorld(loser);
              Greenfoot.playSound("subir nivel.wav");
            }
            
        }
        else {
            verificaVidas();
        }
    }
    
    /**
     * Metodo que espera hasta tocar una moneda
     */
    public void lookForMoneda()
    {
        if ( isTouching(Moneda.class) )
            {
                removeTouching(Moneda.class);
                sumaVida2();
                //Greenfoot.playSound("Chillido de Cerdo");
            }
    }
    
    /**
     * Metodo que espera hasta que toques la telaraña y te de una vida
     */
    public void lookForTelaraña()
    {
        if ( isTouching(Telaraña.class) )
            {
                removeTouching(Telaraña.class);
                vidas++;
                Greenfoot.playSound("vida.wav");
                sumaVida();
                //Greenfoot.playSound("Chillido de Cerdo");
            }
    }
    
    /**
     * Método que muestra en el mundo una roca si la tocas te quita una vida
     */
    public void lookforRocaMata()
    {
        if ( isTouching(RocaMata.class) )
            {
                //removeTouching(RocaMata.class);
                this.setLocation(100,100);
                vidas--;
                Greenfoot.playSound("Noisy spiders.wav");
            }
    }
    
    /**
     * Método que verifica si ya no tienes vidas cuando vodas = 0 envia un texto en pantalla para indicar que perdiste.
     */
    public void verificaVidas()
    {
        if(vidas==0)
        {
            Greenfoot.stop();
            mundo.showText("Usted ha muerto", 650,450);
            Greenfoot.playSound("loser.wav");
        }
    }
    
    /**
     * Metodo que dispara una bala y la elimina cuando llega al finalde al coordenada x
     */
    public void dispara()
    {
        //int x = getWorld().getObjects(Araña.class).getX();
        //getWorld(getObjects(Araña.class).getY());
        if(actor==0)
        {
            mundo.removeObject(a);
        }
        if(disparo==1)
        {
            mundo.addObject(a=new Bala(),xbala,ybala);
            xbala+=50;
            disparo=0;
            actor=1;
            Greenfoot.playSound("disparo.wav");
        }
        else
        {
            if(actor==1)
            {
                a.setLocation(xbala,ybala);
                if(xbala>1300 )
                {
                    mundo.removeObject(a);
                    actor=0;
                }
                else
                {
                    xbala+=50;
                }
            }
        }
        //addObject(new Bala(),this.getX(),this.getX());
    }
    
    /**
     * Método que suma vidas y te pasa al nivel 2
     */
    public void sumaVida()
    {
        mundo2 loser = new mundo2();
        puntos = puntos+10;
         if(vidas > 0)
        {
            if(puntos >= 40)
            {
                Greenfoot.setWorld(loser);
                Greenfoot.playSound("subir nivel.wav");
            }
        }else{
            verificaVidas();
        }
    }
    
    /**
     * Método que quita vidas y si vidas = 0 enviaun mensaje que has muerto
     */
    public int decrementaVidas()
    {
        vidas--;
        Greenfoot.playSound("Noisy spiders.wav");
        if(vidas == 0){
           mundo.showText("Usted ha muerto", 650,450);
           return 0;
            //Greenfoot.playSound("Chillido de Cerdo");
           
        }
        else
        {
            this.setLocation(100,100);
        }
        return 1;
    }
    
    
    
}
