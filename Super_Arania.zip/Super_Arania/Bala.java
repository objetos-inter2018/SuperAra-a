import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase Bala permite elimina del mundo a los enemigos.
 * 
 * @author AIVN
 * @version 4 jul 2018
 */
public class Bala extends Actor
{
    World mundo;
    Araña a;
    /**
     * Act - do whatever the Bala wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        mundo=this.getWorld();
        // Add your action code here.
        lookForCerdo();
        lookForConejo();
        lookForAve();
    }    
    public void lookForCerdo()
    {
        if ( isTouching(Cerdo.class) )
            {
                removeTouching(Cerdo.class);
                //Greenfoot.playSound("Chillido de Cerdo");
            }
    }
    
    public void lookForConejo()
    {
        if ( isTouching(Conejo.class) )
            {
                removeTouching(Conejo.class);
                //Greenfoot.playSound("Chillido de Cerdo");
            }
    }
    
    public void lookForAve()
    {
        if ( isTouching(Ave.class) )
            {
                removeTouching(Ave.class);
                //Greenfoot.playSound("Chillido de Cerdo");
            }
    }
}
