import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class mundo2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mundo2 extends World
{
    int vidas;
    /**
     * constructor de objetos de la clase mundo2.
     * 
     */
    public mundo2()
    {    
        super(1300, 700, 1); 
        
        addObject(new Araña(),100,100);
        addObject(new Moneda(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Conejo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Conejo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Telaraña(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        showText("Nivel 2 ", 650,50);
        vidas = 3;
    }
}
