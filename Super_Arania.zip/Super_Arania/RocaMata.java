import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase RocaMata este al momento de tocarla te quita una vida o te mueres.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RocaMata extends Obstaculo
{
    /**
     * Act - do whatever the RocaMata wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
    }    
}
