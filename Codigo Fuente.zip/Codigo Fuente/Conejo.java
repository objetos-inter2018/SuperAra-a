import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Conejo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Conejo extends Enemigo
{
    World world;
    int movimiento;
    
    /**
     * Constructor de La clase Conejo
     */
    public Conejo()
    {
        movimiento = 15;
    }
    
    /**
     * Act - do whatever the Conejo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        getImage().scale(50,50);
        muevete();
        lookForAraña();
    }    
       
    /**
     * Método Muevete el cual le da un movienito aleatorio al enemigo
     */
    public void muevete()
    {
        if ( isAtEdge() )
            {
                turn(45);
            }
        if ( Greenfoot.getRandomNumber(100) < 2 )
            {
                turn(8);
            }
        if( isTouching(Obstaculo.class))
        {
            turn(10);
        }
        move(movimiento);
        
    }
    
    /**
     * Método que espera a la araña para poder matarla
     */
    public void lookForAraña()
    {
        if ( isTouching(Araña.class) )
            {
                world = getWorld();
                Araña a;
                a = (Araña) getOneIntersectingObject(Araña.class);
                if(a.decrementaVidas() == 0)
                {
                    //removeTouching(Araña.class);
                    //Text perdisto
                }

             }
    }
    
    /**
     * Método que genera puntos a la aranña al matar un conejo
     */
    public void puntos()
    {
        Araña a;
        a = (Araña) getOneIntersectingObject(Araña.class);
        a.sumaVida();
    }
}
