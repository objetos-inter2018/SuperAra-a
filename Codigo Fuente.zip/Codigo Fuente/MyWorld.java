import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Es el mundo del pormer nivel del juego.
 * 
 * @author AIVN 
 * @version 4 jul 2018
 */
public class MyWorld extends World
{
    int x;
    int y;
    int vidas;
    int punto;
    Menu menu;
    /**
     * Contructor de objetos de la clase MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        
        super(1300, 700, 1); 
        menu = new Menu();
                
            addObject(new Araña(),100,100);
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Cerdo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Conejo(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Ave(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMuere(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new RocaMata(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        addObject(new Telaraña(),Greenfoot.getRandomNumber(950)+250, Greenfoot.getRandomNumber(750));
        
        
        
        showText("Nivel 1 ", 650,50);
        vidas = 3;
    }
}
