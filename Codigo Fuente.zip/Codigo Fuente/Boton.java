
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Boton, permite crear los botones que nos permitiran cambiar de escenario
 * 
 * @author AIVN 
 * @version 4 jul 2018
 */
public class Boton extends Actor
{
    private int n;
    /**
     * Constructor Boton
     */
    public Boton(int n)
    {
        this.n=n;
    }
    
    /**
     * Método que muestra los botones definidos, a traves del metodo muestra
     */
    public void act() 
    {
        // Add your action code here.
        muestra(n);
    }
    
    /**
     * Método que crea botones ya definidos dependiendo del parámetro que llega
     */
    public void muestra(int n)
    {
        if(n==1)
            setImage("play.png");
        else
            if(n==2)
                setImage("help.png");
            else
                setImage("exit.png");
    }
}