import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase moneda es un item que da pase al siguiente nivel.
 * 
 * @author AIVN 
 * @version 4 jul 2018
 */
public class Moneda extends Items
{
    /**
     * Act - do whatever the Moneda wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
