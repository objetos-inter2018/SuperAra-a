import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase RocaMuere es un Obstaculo que muere al tocarlo.
 * 
 * @author AIVN 
 * @version 4 jul 2018
 */
public class RocaMuere extends Obstaculo
{
    /**
     * Act - do whatever the RocaMuere wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    /**
     * M[etodo que muere al tocarlo y otorga 10 puntos
     */
    public void puntos()
    {
        Araña a;
        a = (Araña) getOneIntersectingObject(Araña.class);
        a.sumaVida();
    }
}
