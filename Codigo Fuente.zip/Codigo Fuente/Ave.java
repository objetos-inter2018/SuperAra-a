import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ave extends Enemigo
{
    World world;
    /**
     * Act - do whatever the Ave wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        muevete();
        lookForAraña();
    } 
    
    /**
     * Método Muevete el cual le da un movienito aleatorio al enemigo
     */
    public void muevete()
    {
        if ( isAtEdge() )
            {
                turn(25);
            }
        if ( Greenfoot.getRandomNumber(100) < 10 )
            {
                turn(15);
            }
        if( isTouching(Obstaculo.class))
        {
            turn(5);
        }
        move(9);
        
    }
    
    /**
     * Método que espera a la araña para poder matarla
     */
    public void lookForAraña()
    {
        if ( isTouching(Araña.class) )
            {
                world = getWorld();
                Araña a;
                
                a = (Araña) getOneIntersectingObject(Araña.class);
                if(a.decrementaVidas() == 0)
                {
                    //removeTouching(Araña.class);
                    //Text perdisto
                }

             }
    }
    
    /**
     * Método que genera puntos a la araña al matar un ave
     */
    public void puntos()
    {
        Araña a;
        a = (Araña) getOneIntersectingObject(Araña.class);
        a.sumaVida();
    }
}
