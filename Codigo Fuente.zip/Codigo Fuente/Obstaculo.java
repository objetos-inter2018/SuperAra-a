import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase Obtculo hereda a RocaMata y a RocaMuere.
 * 
 * @author  AIVN 
 * @version 4 jul 2018
 */
public class Obstaculo extends Actor
{
    /**
     * Act - do whatever the Obstaculo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
